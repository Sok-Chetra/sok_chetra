import { sendMail } from '@/lib/mail/mailer'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
    try {
        const body = await request.json()
        const { name, email, message } = body

        if (!name || !email || !message) {
            return NextResponse.json(
                { success: false, error: 'All fields are required' },
                { status: 400 }
            )
        }

        const emailContent = `
      <h2>New Contact Form Submission</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Message:</strong></p>
      <p>${message}</p>
    `

        const result = await sendMail({
            to: process.env.CONTACT_FORM_RECIPIENT || process.env.SMTP_USER || '',
            subject: `New message from ${name} - Portfolio Contact`,
            html: emailContent,
        })

        if (!result.success) {
            return NextResponse.json(
                { success: false, error: 'Failed to send email' },
                { status: 500 }
            )
        }

        return NextResponse.json({ success: true })
    } catch (error) {
        console.error('Error in contact form submission:', error)
        return NextResponse.json(
            { success: false, error: 'Internal server error' },
            { status: 500 }
        )
    }
}